<nav>
    <a href="index.php">Home</a>
    <a href="kontak.php">Kontak</a>
    <a href="tentang.php">Tentang Kami</a>
    <a href="login.php">Log in</a>
    <div class="d-inline p-2 text-bg-primary"> </div>
<div class="d-inline p-2 text-bg-dark"> </div>
</nav>